# smart.who.int.base#0.2.0: SMART Base

## Pages

* [Home](index.md)
* [DAK API Documentation Hub](dak-api.md)
* [Artifacts Summary](artifacts.md)
* [Downloads](downloads.md)
* [License](license.md)
* [Changes](changes.md)

## Resources

### CodeSystems

* [Classification of Digital Health Interventions v1](CodeSystem-CDHIv1.md)
* [Classification of Digital Health System Categories v1](CodeSystem-CDSCv1.md)
* [Core Data Element Type](CodeSystem-CoreDataElementType.md)
* [Smart Guidelines Actions (columns) for Decision Tables](CodeSystem-DecisionTableActions.md)
* [Smart Guidelines Documentation Section](CodeSystem-DocumentationSections.md)
* [International Standard Classification of Occupations 2008](CodeSystem-ISCO08.md)
* [SMART Guidelines Persona Types](CodeSystem-SGPersonaTypes.md)
* [SMART Guidelines Tasks](CodeSystem-SGTasks.md)

### ValueSets

* [Classification of Digital Health Interventions v1](ValueSet-CDHIv1.md)
* [Classification of Digital Health System Categories v1](ValueSet-CDSCv1.md)
* [Core Data Element Type Value Set](ValueSet-CoreDataElementTypeVS.md)
* [Smart Guidelines Decision Table Actions](ValueSet-DecisionTableActions.md)
* [Smart Guidelines Documentation Section](ValueSet-DocumentationSection.md)
* [ISCO-08 Value Set](ValueSet-ISCO08ValueSet.md)
* [Smart Guidelines Persona Types Value Set](ValueSet-SGPersonaTypesVS.md)

### Logicals

* [Business Process Workflow (DAK)](StructureDefinition-BusinessProcessWorkflow.md)
* [Business Process Workflow Source](StructureDefinition-BusinessProcessWorkflowSource.md)
* [Core Data Element (DAK)](StructureDefinition-CoreDataElement.md)
* [Core Data Element Source](StructureDefinition-CoreDataElementSource.md)
* [Digital Adaptation Kit (DAK)](StructureDefinition-DAK.md)
* [Decision-Support Logic (DAK)](StructureDefinition-DecisionSupportLogic.md)
* [Decision Support Logic Source](StructureDefinition-DecisionSupportLogicSource.md)
* [Dublin Core Metadata Element Set](StructureDefinition-DublinCore.md)
* [FHIR Schema Base (SMART Guidelines)](StructureDefinition-FHIRSchemaBase.md)
* [Functional Requirement (DAK)](StructureDefinition-FunctionalRequirement.md)
* [Generic Persona (DAK)](StructureDefinition-GenericPersona.md)
* [Generic Persona Source](StructureDefinition-GenericPersonaSource.md)
* [Health Interventions and Recommendations (DAK)](StructureDefinition-HealthInterventions.md)
* [Health Interventions Source](StructureDefinition-HealthInterventionsSource.md)
* [Non-Functional Requirement (DAK)](StructureDefinition-NonFunctionalRequirement.md)
* [Persona (DAK)](StructureDefinition-Persona.md)
* [Program Indicator (DAK)](StructureDefinition-ProgramIndicator.md)
* [Program Indicator Source](StructureDefinition-ProgramIndicatorSource.md)
* [Functional and Non-Functional Requirements (DAK)](StructureDefinition-Requirements.md)
* [Requirements Source](StructureDefinition-RequirementsSource.md)
* [SUSHI Configuration Logical Model](StructureDefinition-SushiConfigLogicalModel.md)
* [Test Scenario (DAK)](StructureDefinition-TestScenario.md)
* [Test Scenario Source](StructureDefinition-TestScenarioSource.md)
* [User Scenario (DAK)](StructureDefinition-UserScenario.md)
* [User Scenario Source](StructureDefinition-UserScenarioSource.md)

### Resource Profiles

* [SMART Guidelines ActivityDefinition](StructureDefinition-SGActivityDefinition.md)
* [SGActor](StructureDefinition-SGActor.md)
* [SMART Guidelines Business Process](StructureDefinition-SGBusinessProcess.md)
* [SMART Guidelines CodeSystem](StructureDefinition-SGCodeSystem.md)
* [SMART Guidelines Communication Request](StructureDefinition-SGCommunicationRequest.md)
* [SMART Guidelines ConceptMap](StructureDefinition-SGConceptMap.md)
* [SMART Guidelines Decision Table](StructureDefinition-SGDecisionTable.md)
* [SGGraphDefinition](StructureDefinition-SGGraphDefinition.md)
* [WHO SMART Guidelines Group Definition](StructureDefinition-SGGroupDefinition.md)
* [SMART Guidelines ImplementationGuide](StructureDefinition-SGImplementationGuide.md)
* [SMART Guidelines Library](StructureDefinition-SGLibrary.md)
* [SMART Guidelines Logical Model](StructureDefinition-SGLogicalModel.md)
* [SMART Guidelines Measure](StructureDefinition-SGMeasure.md)
* [SMART Guidelines PlanDefinition](StructureDefinition-SGPlanDefinition.md)
* [SMART Guidelines Questionnaire](StructureDefinition-SGQuestionnaire.md)
* [SMART Guidelines Requirements](StructureDefinition-SGRequirements.md)
* [SMART Guidelines StructureDefinition](StructureDefinition-SGStructureDefinition.md)
* [SMART Guidelines StructureMap](StructureDefinition-SGStructureMap.md)
* [SGTransaction](StructureDefinition-SGTransaction.md)
* [SMART Guidelines ValueSet](StructureDefinition-SGValueSet.md)

### Extensions

* [LinkIdExt](StructureDefinition-LinkIdExt.md)
* [Markdown](StructureDefinition-Markdown.md)
* [SGActorExt](StructureDefinition-SGActorExt.md)
* [SGDocumentation](StructureDefinition-SGDocumentation.md)
* [SGMarkdown](StructureDefinition-SGMarkdown.md)
* [SGRequirementExt](StructureDefinition-SGRequirementExt.md)
* [SGString](StructureDefinition-SGString.md)
* [SGTask](StructureDefinition-SGTask.md)
* [SGUserStory](StructureDefinition-SGUserStory.md)
* [SGcode](StructureDefinition-SGcode.md)
* [Satisfies](StructureDefinition-Satisfies.md)

### ActivityDefinitions

* [SGDecisionTableGuidance](ActivityDefinition-SGDecisionTableGuidance.md)

### ConceptMaps

* [Hierarchy of the Classification of Digital Health Interventions v1](ConceptMap-CDHIv1Hierarchy.md)

### ImplementationGuides

* [SMART Base](index.md)

### Questionnaires

* [IMMZ.D2 Determine required vaccination(s) if any](Questionnaire-DAK.DT.IMMZ.D2.DT.BCGQuestionnaire.md)
