# Health Management Information System (HMIS) - Testing - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health Management Information System (HMIS)**

## ActorDefinition: Health Management Information System (HMIS) - Testing (Experimental) 

| |
| :--- |
| Draft as of 2026-10-07 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

