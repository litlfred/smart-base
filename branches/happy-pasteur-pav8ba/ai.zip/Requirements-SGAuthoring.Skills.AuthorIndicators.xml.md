# Can author indicators - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author indicators**

## : Can author indicators - XML Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorIndicators.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorIndicators.xml)

