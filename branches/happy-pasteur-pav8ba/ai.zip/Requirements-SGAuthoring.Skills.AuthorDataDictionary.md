# Can author data dictionary - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author data dictionary**

## Requirements: Can author data dictionary (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorDataDictionary | *Version*:0.3.0 |
| Draft as of 2026-10-07 | *Computable Name*:SkillAuthorDataDictionary |

 
Capability to define core data elements and map to standard terminologies. 

