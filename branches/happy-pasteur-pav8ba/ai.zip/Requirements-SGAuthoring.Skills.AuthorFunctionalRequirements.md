# Can author functional requirements - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author functional requirements**

## Requirements: Can author functional requirements (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorFunctionalRequirements | *Version*:0.3.0 |
| Draft as of 2026-10-07 | *Computable Name*:SkillAuthorFunctionalRequirements |

 
Capability to define high-level functional and non-functional requirements linked to personas and business processes. 

