# Can author FHIR requirements - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author FHIR requirements**

## : Can author FHIR requirements - TTL Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw ttl](Requirements-SGAuthoring.Skills.AuthorFHIRRequirements.ttl) | [Download](Requirements-SGAuthoring.Skills.AuthorFHIRRequirements.ttl)

