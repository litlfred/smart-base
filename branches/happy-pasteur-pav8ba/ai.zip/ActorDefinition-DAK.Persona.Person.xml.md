# Person (Health Service User) - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Person (Health Service User)**

## : Person (Health Service User) - XML Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw xml](ActorDefinition-DAK.Persona.Person.xml) | [Download](ActorDefinition-DAK.Persona.Person.xml)

