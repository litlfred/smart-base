# Translator - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Translator**

## : Translator - TTL Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw ttl](ActorDefinition-SGAuthoring.Persona.Translator.ttl) | [Download](ActorDefinition-SGAuthoring.Persona.Translator.ttl)

