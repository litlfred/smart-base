# Can configure IG - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can configure IG**

## : Can configure IG - XML Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw xml](Requirements-SGAuthoring.Skills.ConfigureIG.xml) | [Download](Requirements-SGAuthoring.Skills.ConfigureIG.xml)

