# Can map concepts - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can map concepts**

## : Can map concepts - XML Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw xml](Requirements-SGAuthoring.Skills.MapConcepts.xml) | [Download](Requirements-SGAuthoring.Skills.MapConcepts.xml)

