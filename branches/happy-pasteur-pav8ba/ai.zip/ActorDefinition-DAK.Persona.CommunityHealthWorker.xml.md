# Community Health Worker - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Community Health Worker**

## : Community Health Worker - XML Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw xml](ActorDefinition-DAK.Persona.CommunityHealthWorker.xml) | [Download](ActorDefinition-DAK.Persona.CommunityHealthWorker.xml)

