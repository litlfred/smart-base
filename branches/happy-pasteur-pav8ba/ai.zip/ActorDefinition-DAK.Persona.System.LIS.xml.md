# Laboratory Information System (LIS) - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Laboratory Information System (LIS)**

## : Laboratory Information System (LIS) - XML Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw xml](ActorDefinition-DAK.Persona.System.LIS.xml) | [Download](ActorDefinition-DAK.Persona.System.LIS.xml)

