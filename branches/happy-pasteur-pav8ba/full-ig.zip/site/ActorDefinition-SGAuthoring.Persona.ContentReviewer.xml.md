# Content Reviewer / Approver - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Content Reviewer / Approver**

## : Content Reviewer / Approver - XML Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw xml](ActorDefinition-SGAuthoring.Persona.ContentReviewer.xml) | [Download](ActorDefinition-SGAuthoring.Persona.ContentReviewer.xml)

