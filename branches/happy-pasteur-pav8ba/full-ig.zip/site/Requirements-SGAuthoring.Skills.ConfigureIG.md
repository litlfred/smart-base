# Can configure IG - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can configure IG**

## Requirements: Can configure IG (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.ConfigureIG | *Version*:0.3.0 |
| Draft as of 2026-10-07 | *Computable Name*:SkillConfigureIG |

 
Capability to set up and configure a FHIR Implementation Guide (sushi-config, canonical URL, packages). 

