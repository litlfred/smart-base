# Can author functional requirements - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author functional requirements**

## : Can author functional requirements - XML Representation

| |
| :--- |
| Draft as of 2026-10-07 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorFunctionalRequirements.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorFunctionalRequirements.xml)

