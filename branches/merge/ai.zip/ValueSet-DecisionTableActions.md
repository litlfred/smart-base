# Smart Guidelines Decision Table Actions - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Smart Guidelines Decision Table Actions**

## ValueSet: Smart Guidelines Decision Table Actions (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ValueSet/DecisionTableActions | *Version*:0.2.0 |
| Active as of 2026-03-03 | *Computable Name*:DecisionTableActions |

 
Value Set for Smart Guidelines Documentation Decision Table Actions 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### Smart Guidelines Decision Table Actions Schema API

JSON Schema for Smart Guidelines Decision Table Actions ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-DecisionTableActions.schema.json

#### JSON Schema definition for the enumeration ValueSet-DecisionTableActions

This endpoint serves the JSON Schema definition for the enumeration ValueSet-DecisionTableActions.

## Schema Definition

### ValueSet-DecisionTableActions

**Description:** JSON Schema for Smart Guidelines Decision Table Actions ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "DecisionTableActions",
  "url" : "http://smart.who.int/base/ValueSet/DecisionTableActions",
  "version" : "0.2.0",
  "name" : "DecisionTableActions",
  "title" : "Smart Guidelines Decision Table Actions",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-03-03T12:04:05+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Value Set for Smart Guidelines Documentation Decision Table Actions",
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/base/CodeSystem/DecisionTableActions"
    }]
  }
}

```
