# Can interpret clinical recommendations - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can interpret clinical recommendations**

## Requirements: Can interpret clinical recommendations (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.InterpretClinicalRecommendations | *Version*:0.3.0 |
| Draft as of 2026-10-22 | *Computable Name*:SkillInterpretClinicalRecommendations |

 
Capability to interpret clinical recommendations from L1 source documents with domain expertise. 

