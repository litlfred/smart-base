# Can review and approve content - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can review and approve content**

## Requirements: Can review and approve content (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.ReviewAndApproveContent | *Version*:0.3.0 |
| Draft as of 2026-10-22 | *Computable Name*:SkillReviewAndApproveContent |

 
Capability to review and formally approve SMART Guidelines content at decision gates in the authoring lifecycle. 

