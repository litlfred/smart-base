# Publication Manager - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Publication Manager**

## : Publication Manager - JSON Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw json](ActorDefinition-SGAuthoring.Persona.PublicationManager.json) | [Download](ActorDefinition-SGAuthoring.Persona.PublicationManager.json)

