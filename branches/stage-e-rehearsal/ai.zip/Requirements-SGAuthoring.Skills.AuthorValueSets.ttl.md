# Can author value sets - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author value sets**

## : Can author value sets - TTL Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw ttl](Requirements-SGAuthoring.Skills.AuthorValueSets.ttl) | [Download](Requirements-SGAuthoring.Skills.AuthorValueSets.ttl)

