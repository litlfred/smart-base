# FHIR Modeller - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FHIR Modeller**

## : FHIR Modeller - TTL Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw ttl](ActorDefinition-SGAuthoring.Persona.FHIRModeller.ttl) | [Download](ActorDefinition-SGAuthoring.Persona.FHIRModeller.ttl)

