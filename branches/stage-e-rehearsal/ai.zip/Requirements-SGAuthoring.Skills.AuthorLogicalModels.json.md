# Can author logical models - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author logical models**

## : Can author logical models - JSON Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw json](Requirements-SGAuthoring.Skills.AuthorLogicalModels.json) | [Download](Requirements-SGAuthoring.Skills.AuthorLogicalModels.json)

