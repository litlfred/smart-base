# SMART Guidelines Library - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SMART Guidelines Library**

## Resource Profile: SMART Guidelines Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/StructureDefinition/SGLibrary | *Version*:0.3.0 |
| Draft as of 2026-10-02 | *Computable Name*:SGLibrary |

 
Defines the minimum expectations for Library resources used in SMART Guidelines 

**Usages:**

* Refer to this Profile: [SMART Guidelines ImplementationGuide](StructureDefinition-SGImplementationGuide.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/smart.who.int.base|current/StructureDefinition/StructureDefinition-SGLibrary.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-SGLibrary.csv), [Excel](StructureDefinition-SGLibrary.xlsx), [Schematron](StructureDefinition-SGLibrary.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "SGLibrary",
  "url" : "http://smart.who.int/base/StructureDefinition/SGLibrary",
  "version" : "0.3.0",
  "name" : "SGLibrary",
  "title" : "SMART Guidelines Library",
  "status" : "draft",
  "date" : "2026-10-02T12:02:08+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Defines the minimum expectations for Library resources used in SMART Guidelines",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "objimpl",
    "uri" : "http://hl7.org/fhir/object-implementation",
    "name" : "Object Implementation Information"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Library",
  "baseDefinition" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablelibrary",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Library",
      "path" : "Library"
    },
    {
      "id" : "Library.name",
      "path" : "Library.name",
      "min" : 1
    },
    {
      "id" : "Library.publisher",
      "path" : "Library.publisher",
      "min" : 1
    }]
  }
}

```
