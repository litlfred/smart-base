# Client Registry / Master Patient Index - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Client Registry / Master Patient Index**

## : Client Registry / Master Patient Index - TTL Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw ttl](ActorDefinition-DAK.Persona.System.ClientRegistry.ttl) | [Download](ActorDefinition-DAK.Persona.System.ClientRegistry.ttl)

