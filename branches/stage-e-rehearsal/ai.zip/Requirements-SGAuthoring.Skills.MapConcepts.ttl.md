# Can map concepts - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can map concepts**

## : Can map concepts - TTL Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw ttl](Requirements-SGAuthoring.Skills.MapConcepts.ttl) | [Download](Requirements-SGAuthoring.Skills.MapConcepts.ttl)

