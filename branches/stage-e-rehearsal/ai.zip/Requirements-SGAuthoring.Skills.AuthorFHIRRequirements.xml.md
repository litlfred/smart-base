# Can author FHIR requirements - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author FHIR requirements**

## : Can author FHIR requirements - XML Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorFHIRRequirements.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorFHIRRequirements.xml)

