# Can author example scenarios - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author example scenarios**

## Requirements: Can author example scenarios (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorExampleScenarios | *Version*:0.3.0 |
| Draft as of 2026-10-02 | *Computable Name*:SkillAuthorExampleScenarios |

 
Capability to create ExampleScenario resources from L2 user scenarios. 

