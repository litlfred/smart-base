# Can author test cases - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author test cases**

## : Can author test cases - JSON Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw json](Requirements-SGAuthoring.Skills.AuthorTestCases.json) | [Download](Requirements-SGAuthoring.Skills.AuthorTestCases.json)

