# Can review terminology - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can review terminology**

## : Can review terminology - XML Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw xml](Requirements-SGAuthoring.Skills.ReviewTerminology.xml) | [Download](Requirements-SGAuthoring.Skills.ReviewTerminology.xml)

