# Laboratory Information System (LIS) - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Laboratory Information System (LIS)**

## ActorDefinition: Laboratory Information System (LIS) (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ActorDefinition/DAK.Persona.System.LIS | *Version*:0.3.0 |
| Draft as of 2026-10-02 | *Computable Name*:LaboratoryInformationSystem |

 
A digital system that manages the complete lifecycle of laboratory test orders, specimen tracking, result production, and result reporting to healthcare providers and persons. 
The LIS supports DHIs including: 
* Transmit and track diagnostic orders (2.10.2)
* Capture diagnostic results from digital devices (2.10.3)
* Transmit person's diagnostic result to healthcare provider (2.10.1)
* Transmit diagnostics result or availability of result to person(s) (1.1.4)
* Track biological specimens (2.10.4)
 
**Services and Application Type**: A6 — Laboratory information systems 
**Functional areas**: Lab requests/test ordering, sample tracking, sample processing, results reporting. 

