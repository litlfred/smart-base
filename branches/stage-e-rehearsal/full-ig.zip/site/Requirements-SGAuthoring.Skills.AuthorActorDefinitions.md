# Can author actor definitions - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author actor definitions**

## Requirements: Can author actor definitions (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorActorDefinitions | *Version*:0.3.0 |
| Draft as of 2026-10-02 | *Computable Name*:SkillAuthorActorDefinitions |

 
Capability to create FHIR ActorDefinitions from L2 personas, reusing existing definitions from the Commons repository. 

