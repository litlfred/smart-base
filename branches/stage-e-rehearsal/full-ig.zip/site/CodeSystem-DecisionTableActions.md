# Smart Guidelines Actions (columns) for Decision Tables - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Smart Guidelines Actions (columns) for Decision Tables**

## CodeSystem: Smart Guidelines Actions (columns) for Decision Tables 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/CodeSystem/DecisionTableActions | *Version*:0.3.0 |
| Active as of 2026-10-02 | *Computable Name*:DecisionTableActions |

 
CodeSystem for Smart Guidelines Documentation Actions for Decision Tables" 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Smart Guidelines Decision Table Actions](ValueSet-DecisionTableActions.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "DecisionTableActions",
  "url" : "http://smart.who.int/base/CodeSystem/DecisionTableActions",
  "version" : "0.3.0",
  "name" : "DecisionTableActions",
  "title" : "Smart Guidelines Actions (columns) for Decision Tables",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-02T12:02:08+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "CodeSystem for Smart Guidelines Documentation Actions for Decision Tables\"",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 3,
  "concept" : [{
    "code" : "output",
    "display" : "Output"
  },
  {
    "code" : "guidance",
    "display" : "Guidance"
  },
  {
    "code" : "annotation",
    "display" : "Annotation"
  }]
}

```
