# Can review translations - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can review translations**

## : Can review translations - JSON Representation

| |
| :--- |
| Draft as of 2026-10-02 |

[Raw json](Requirements-SGAuthoring.Skills.ReviewTranslations.json) | [Download](Requirements-SGAuthoring.Skills.ReviewTranslations.json)

