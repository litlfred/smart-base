# Health System Manager - Testing - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health System Manager**

## ActorDefinition: Health System Manager - Testing (Experimental) 

| |
| :--- |
| Draft as of 2026-03-11 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

