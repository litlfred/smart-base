# Can configure IG - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can configure IG**

## : Can configure IG - JSON Representation

| |
| :--- |
| Draft as of 2026-03-23 |

[Raw json](Requirements-SGAuthoring.Skills.ConfigureIG.json) | [Download](Requirements-SGAuthoring.Skills.ConfigureIG.json)

