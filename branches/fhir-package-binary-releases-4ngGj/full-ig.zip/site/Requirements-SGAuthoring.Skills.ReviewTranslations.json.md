# Can review translations - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can review translations**

## : Can review translations - JSON Representation

| |
| :--- |
| Draft as of 2026-03-23 |

[Raw json](Requirements-SGAuthoring.Skills.ReviewTranslations.json) | [Download](Requirements-SGAuthoring.Skills.ReviewTranslations.json)

