# Can author code systems - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author code systems**

## Requirements: Can author code systems (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorCodeSystems | *Version*:0.3.0 |
| Draft as of 2026-10-06 | *Computable Name*:SkillAuthorCodeSystems |

 
Capability to create and maintain FHIR CodeSystem resources. 

