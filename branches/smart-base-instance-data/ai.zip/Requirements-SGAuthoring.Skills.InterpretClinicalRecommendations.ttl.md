# Can interpret clinical recommendations - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can interpret clinical recommendations**

## : Can interpret clinical recommendations - TTL Representation

| |
| :--- |
| Draft as of 2026-10-06 |

[Raw ttl](Requirements-SGAuthoring.Skills.InterpretClinicalRecommendations.ttl) | [Download](Requirements-SGAuthoring.Skills.InterpretClinicalRecommendations.ttl)

