# Can author scheduling logic - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author scheduling logic**

## : Can author scheduling logic - XML Representation

| |
| :--- |
| Draft as of 2026-10-06 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorSchedulingLogic.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorSchedulingLogic.xml)

