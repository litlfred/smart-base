# Can review L1 guidelines - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can review L1 guidelines**

## Requirements: Can review L1 guidelines (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.ReviewL1Guidelines | *Version*:0.3.0 |
| Draft as of 2026-10-06 | *Computable Name*:SkillReviewL1Guidelines |

 
Capability to review WHO L1 narrative guidelines and normative products for accuracy and completeness. 

