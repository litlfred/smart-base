# Clinical Subject Matter Expert - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Clinical Subject Matter Expert**

## : Clinical Subject Matter Expert - TTL Representation

| |
| :--- |
| Draft as of 2026-10-06 |

[Raw ttl](ActorDefinition-SGAuthoring.Persona.ClinicalSME.ttl) | [Download](ActorDefinition-SGAuthoring.Persona.ClinicalSME.ttl)

