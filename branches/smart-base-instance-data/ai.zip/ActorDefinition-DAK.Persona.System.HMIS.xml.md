# Health Management Information System (HMIS) - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health Management Information System (HMIS)**

## : Health Management Information System (HMIS) - XML Representation

| |
| :--- |
| Draft as of 2026-10-06 |

[Raw xml](ActorDefinition-DAK.Persona.System.HMIS.xml) | [Download](ActorDefinition-DAK.Persona.System.HMIS.xml)

