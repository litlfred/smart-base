# Health Data Manager and Analyst - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health Data Manager and Analyst**

## : Health Data Manager and Analyst - TTL Representation

| |
| :--- |
| Draft as of 2026-10-06 |

[Raw ttl](ActorDefinition-DAK.Persona.DataManager.ttl) | [Download](ActorDefinition-DAK.Persona.DataManager.ttl)

