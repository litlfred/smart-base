# Terminologist - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Terminologist**

## : Terminologist - XML Representation

| |
| :--- |
| Draft as of 2026-10-06 |

[Raw xml](ActorDefinition-SGAuthoring.Persona.Terminologist.xml) | [Download](ActorDefinition-SGAuthoring.Persona.Terminologist.xml)

