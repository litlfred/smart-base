# Can validate artifact conformance - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can validate artifact conformance**

## : Can validate artifact conformance - XML Representation

| |
| :--- |
| Draft as of 2026-10-06 |

[Raw xml](Requirements-SGAuthoring.Skills.ValidateArtifactConformance.xml) | [Download](Requirements-SGAuthoring.Skills.ValidateArtifactConformance.xml)

