# Public Health and Disease Surveillance System - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Public Health and Disease Surveillance System**

## : Public Health and Disease Surveillance System - XML Representation

| |
| :--- |
| Draft as of 2026-08-26 |

[Raw xml](ActorDefinition-DAK.Persona.System.SurveillanceSystem.xml) | [Download](ActorDefinition-DAK.Persona.System.SurveillanceSystem.xml)

